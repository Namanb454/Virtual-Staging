Hello,

Thank you for downloading my Font

To display the Special Characters of a font on Illustrator, 
hit Window > Type > Glyphs. 

To display the Special Characters of a font on Photoshop, 
hit Window > Glyphs. 

Illustrator / Photoshop will display the Glyphs Panel. 
The glyphs are all the characters that a font includes. 

To add a glyph to your text, Select the text  
just double click on Glyphs Panel to change

Thanks